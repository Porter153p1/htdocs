<?php
    $nameAdmin="pepe";

    $passwordAdmin="1234";
?>